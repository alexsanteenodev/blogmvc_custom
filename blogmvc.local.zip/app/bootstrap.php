<?php
/**
 * Created by PhpStorm.
 * User: santeeno
 * Date: 23.05.2016
 * Time: 14:45
 */
namespace app;


require_once 'base/model.php';
require_once 'base/view.php';
require_once 'base/controller.php';
require_once 'route.php';
Route::start();