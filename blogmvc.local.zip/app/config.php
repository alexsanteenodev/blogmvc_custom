<?php
/**
 * Created by PhpStorm.
 * User: santeeno
 * Date: 23.05.2016
 * Time: 17:34
 */

$dbhost = 'localhost';
$dbname = 'blogmvc';
$dbuser = 'root';
$dbpassword='14678211';
