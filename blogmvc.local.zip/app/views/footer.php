
<div class="blog-footer col-sm-8 col-sm-offset-2">

    <p>
        <a href="#">Вверх</a>
    </p>
</div>


</body>
</html>